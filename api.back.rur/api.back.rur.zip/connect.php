<?php

$conn = mysqli_connect('localhost', 'u2099301_4pi4', '2811301102gG', 'u2099301_4pi4');

if (!$conn) {
    echo 'error';
}